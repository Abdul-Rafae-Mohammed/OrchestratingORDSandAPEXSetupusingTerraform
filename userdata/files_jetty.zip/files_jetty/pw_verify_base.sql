set head off feed off
alter profile default limit password_verify_function ToBeUpdated_PW_VERIFY_FUNC;
exit
